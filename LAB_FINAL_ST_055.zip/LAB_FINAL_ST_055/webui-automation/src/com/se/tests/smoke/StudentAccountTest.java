package com.se.tests.smoke;

import com.se.rolesbase.StudentLoginBase;
import org.testng.annotations.Test;
import com.se.utils.NavigationUtil;
import com.se.utils.UtilsSet;
import org.testng.Assert;
import com.se.config.Constants;

public class StudentAccountTest extends StudentLoginBase {

    @Test
    public void verifyStudentIsLoggedIn(){
        System.out.println("A Student is now logged in");
    }

    @Test
    public void verifyWelcomeToTrainStudent(){
        // Placeholder for another test case
    }

    @Test(dependsOnMethods = {"verifyStudentIsLoggedIn"})
    public void verifyDueExameButtonIsClicked() {
        System.out.println("Starting verifyDueExamButtonIsClicked test");
        NavigationUtil.clickDueExameButton();
        System.out.println("Due Exam button is clicked");

        try {
            int timeoutSeconds = 27;

            UtilsSet.waitForElementToBeVisible(Constants.DueExame.BY_dueExameSection, timeoutSeconds);
            String dueExameSectionText = UtilsSet.getElementText(Constants.DueExame.BY_dueExameSection);
            System.out.println("Due Exame section is visible with text: " + dueExameSectionText);

            Assert.assertFalse(dueExameSectionText.isEmpty(), "dueExameSectionText should not be empty");
            Assert.assertEquals(dueExameSectionText, "Exams", "Mismatch text when the Due Exame button is clicked");
            System.out.println("verifyDueExameButtonIsClicked test completed successfully");
        } catch (Exception e) {
            System.err.println("The dueExameSectionElement was not found or did not behave as expected.");
            Assert.fail("The dueExameSectionElement was not found or did not behave as expected.", e);
        }
    }

    @Test(dependsOnMethods = {"verifyStudentIsLoggedIn", "verifyDueExameButtonIsClicked"})
    public void verifyExamTitleLinkIsClicked() {
        System.out.println("Starting verifyExameTitleLinkIsClicked test");
        NavigationUtil.clickQuizTitleLink();
        System.out.println("The quiz title link is clicked");

        try{
            int timeoutSeconds = 60;

            UtilsSet.waitForElementToBeVisible(Constants.DueExame.BY_examSummarySection, timeoutSeconds);

            UtilsSet.scrollToElement(Constants.DueExame.BY_examSummarySection);

            String examSummarySectionText = UtilsSet.getElementText(Constants.DueExame.BY_examSummarySection);
            System.out.println("Exam Summary section is visible with text: " + examSummarySectionText);
            Assert.assertFalse(examSummarySectionText.isEmpty(), "examSummarySection should not be empty");
            Assert.assertEquals(examSummarySectionText, "Quiz 1 SP24 in Software Testing", "Mismatch text when the exam title link is clicked");
            System.out.println("verifyExamTitleLinkIsClicked test completed successfully");
        } catch (Exception e) {
            System.err.println("The verifyExamTitleLink was not found or did not behave as expected.");
            Assert.fail("The verifyExamTitleLink was not found or did not behave as expected.", e);
        }}







//    LAb FINAL Hamza Badar 055 Question Paper and Performance Analytics

    @Test(dependsOnMethods = {"verifyStudentIsLoggedIn", "verifyDueExameButtonIsClicked", "verifyExamTitleLinkIsClicked"})
    public void verifyQuestionPaperButtonIsClicked() {
        System.out.println("Starting verifyQuestionPaperButtonIsClicked test");
        NavigationUtil.clickQuestionPaperButton();
        System.out.println("Question Paper button is clicked");

        try {
            int timeoutSeconds = 60;
            UtilsSet.waitForElementToBeVisible(Constants.DueExame.BY_questionPaperSummarySection, timeoutSeconds);
            String questionPaperSummaryText = UtilsSet.getElementText(Constants.DueExame.BY_questionPaperSummarySection);
            System.out.println("Question Paper Summary section is visible with text: " + questionPaperSummaryText);

            Assert.assertFalse(questionPaperSummaryText.isEmpty(), "questionPaperSummaryText should not be empty");
            Assert.assertEquals(questionPaperSummaryText, "Question Paper", "Mismatch text when the Question Paper button is clicked");
            System.out.println("verifyQuestionPaperButtonIsClicked test completed successfully");
        } catch (Exception e) {
            System.err.println("The questionPaperSummarySectionElement was not found or did not behave as expected.");
            Assert.fail("The questionPaperSummarySectionElement was not found or did not behave as expected.", e);
        }
    }
    @Test(dependsOnMethods = {"verifyStudentIsLoggedIn", "verifyDueExameButtonIsClicked", "verifyExamTitleLinkIsClicked"})
    public void verifyPerformanceAnalyticsButtonIsClicked() {
        System.out.println("Starting verifyPerformanceAnalyticsButtonIsClicked test");

        NavigationUtil.clickPerformanceAnalyticsButton();
        System.out.println("Performance Analytics button is clicked");

        try {
            int timeoutSeconds = 60;

            UtilsSet.waitForElementToBeVisible(Constants.DueExame.BY_performanceAnalyticsSummarySection, timeoutSeconds);

            String performanceAnalyticsSummaryText = UtilsSet.getElementText(Constants.DueExame.BY_performanceAnalyticsSummarySection);
            System.out.println("Performance Analytics Summary section is visible with text: " + performanceAnalyticsSummaryText);

            Assert.assertFalse(performanceAnalyticsSummaryText.isEmpty(), "performanceAnalyticsSummaryText should not be empty");
            Assert.assertEquals(performanceAnalyticsSummaryText, "Exam Performance of Student and Class", "Mismatch text when the Performance Analytics button is clicked");
            System.out.println("verifyPerformanceAnalyticsButtonIsClicked test completed successfully");
        } catch (Exception e) {
            System.err.println("The performanceAnalyticsSummarySectionElement was not found or did not behave as expected.");
            Assert.fail("The performanceAnalyticsSummarySectionElement was not found or did not behave as expected.", e);
        }
    }



}