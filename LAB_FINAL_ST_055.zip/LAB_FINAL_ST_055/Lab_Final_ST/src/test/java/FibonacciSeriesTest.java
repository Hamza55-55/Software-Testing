/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author badar
 */
public class FibonacciSeriesTest {
    
    public FibonacciSeriesTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of Fibonacci method, of class FibonacciSeries.
     */
    @Test
    public void specialcharacters() {
        System.out.println("For special characters");
        int counter = '&';
        FibonacciSeries instance = new FibonacciSeries();
        List<Integer> expResult = Arrays.asList(0, 1, 1, 2, 3, 5, 8, 13);
        List<Integer> result = instance.Fibonacci(counter);
        assertEquals(expResult, result);
    }
        @Test
    public void negativecounter() {
        System.out.println("For negative characters");
        int counter = -8;
        FibonacciSeries instance = new FibonacciSeries();
        List<Integer> expResult = new ArrayList<>();
        List<Integer> result = instance.Fibonacci(counter);
        assertEquals(expResult, result);
    }    
    
    @Test
 public void characters() {
    System.out.println("For characters");
    
    String input = "hamza"; 
    int counter;
    
    try {
        counter = Integer.parseInt(input); 
    } catch (NumberFormatException e) {
        IllegalArgumentException expException = new IllegalArgumentException("Input must be a positive integer not a character.", e);
        assertEquals("Input must be a positive integer not a character.", expException.getMessage());
        return;
    }
    
    FibonacciSeries instance = new FibonacciSeries();
    List<Integer> result = instance.Fibonacci(counter);
   
}


        @Test
    public void countervalue1() {
        System.out.println("For counter equal to 1");
        int counter = 1;
        FibonacciSeries instance = new FibonacciSeries();
        int expResult=0;
        List<Integer> result = instance.Fibonacci(counter);
        assertEquals(expResult, result);
    }
     @Test
    public void testFibonacciWithLargeCounter() {
        System.out.println("For counter greater than the limit");
        int counter = 1000000000;
        FibonacciSeries fb = new FibonacciSeries();
        try {
            fb.Fibonacci(counter);
            fail("Expected IllegalArgumentException for counter greater than the limit");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid input: Counter exceeds the maximum limit.", e.getMessage());
        }
    }
    /**
     * Test of main method, of class FibonacciSeries.
     */
    @Test
    public void testMain() {
        String[] args = null;
        FibonacciSeries.main(args);
    }
    
}
