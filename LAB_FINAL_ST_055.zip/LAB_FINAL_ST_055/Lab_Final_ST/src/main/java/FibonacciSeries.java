import java.util.ArrayList;
import java.util.List;

public class FibonacciSeries {

    public List<Integer> Fibonacci(int counter) {
        List<Integer> fibonacciSeries = new ArrayList<>();

        if (counter <= 0) {
            System.out.println("Invalid input: Please enter a valid positive integer.");
            return fibonacciSeries;
        }
         if (counter > 1000000000) {
            System.out.println("Invalid input: Counter exceeds the maximum limit.");
            return fibonacciSeries;
        }

        int a = 0, b = 1;
        fibonacciSeries.add(a);
        fibonacciSeries.add(b);

        for (int i = 2; i < counter; i++) {
            int c = a + b;
            fibonacciSeries.add(c);
            a = b;
            b = c; 
        }

        return fibonacciSeries;
    }

    public static void main(String args[]) {
        FibonacciSeries fb = new FibonacciSeries();
        List<Integer> series = fb.Fibonacci(8);
        System.out.println(series);
    }
}
