package com.se.tests.smoke;

import com.se.rolesbase.StudentLoginBase;
import org.testng.annotations.Test;
import com.se.utils.NavigationUtil;
import com.se.utils.UtilsSet;
import org.testng.Assert;
import com.se.config.Constants;

public class StudentAccountTest extends StudentLoginBase {

    @Test
    public void verifyStudentIsLoggedIn(){
        System.out.println("A Student is now logged in");
    }

    @Test
    public void verifyWelcomeToTrainStudent(){
        // Placeholder for another test case
    }
//    1.

    @Test(dependsOnMethods = {"verifyStudentIsLoggedIn"})
    public void verifyDueExameButtonIsClicked() {
        System.out.println("Starting verifyDueExamButtonIsClicked test");
        NavigationUtil.clickDueExameButton();
        System.out.println("Due Exam button is clicked");

        try {
            int timeoutSeconds = 27;

            UtilsSet.waitForElementToBeVisible(Constants.DueExame.BY_dueExameSection, timeoutSeconds);
            String dueExameSectionText = UtilsSet.getElementText(Constants.DueExame.BY_dueExameSection);
            System.out.println("Due Exame section is visible with text: " + dueExameSectionText);

            Assert.assertFalse(dueExameSectionText.isEmpty(), "dueExameSectionText should not be empty");
            Assert.assertEquals(dueExameSectionText, "Exams", "Mismatch text when the Due Exame button is clicked");
            System.out.println("verifyDueExameButtonIsClicked test completed successfully");
        } catch (Exception e) {
            System.err.println("The dueExameSectionElement was not found or did not behave as expected.");
            Assert.fail("The dueExameSectionElement was not found or did not behave as expected.", e);
        }
    }

    @Test(dependsOnMethods = {"verifyStudentIsLoggedIn", "verifyDueExameButtonIsClicked"})
    public void verifyExamTitleLinkIsClicked() {
        System.out.println("Starting verifyExameTitleLinkIsClicked test");
        NavigationUtil.clickQuizTitleLink();
        System.out.println("The quiz title link is clicked");

        try{
            int timeoutSeconds = 60;

            UtilsSet.waitForElementToBeVisible(Constants.DueExame.BY_examSummarySection, timeoutSeconds);

            // Scroll to the Exam Summary section
            UtilsSet.scrollToElement(Constants.DueExame.BY_examSummarySection);

            String examSummarySectionText = UtilsSet.getElementText(Constants.DueExame.BY_examSummarySection);
            System.out.println("Exam Summary section is visible with text: " + examSummarySectionText);
            Assert.assertFalse(examSummarySectionText.isEmpty(), "examSummarySection should not be empty");
            Assert.assertEquals(examSummarySectionText, "Quiz 1 SP24 in Software Testing", "Mismatch text when the exam title link is clicked");
            System.out.println("verifyExamTitleLinkIsClicked test completed successfully");
        } catch (Exception e) {
            System.err.println("The verifyExamTitleLink was not found or did not behave as expected.");
            Assert.fail("The verifyExamTitleLink was not found or did not behave as expected.", e);
        }}

    @Test(dependsOnMethods = {"verifyStudentIsLoggedIn","verifyDueExameButtonIsClicked", "verifyExamTitleLinkIsClicked"})
    public void verifyBackNavigationFromExamSummary() {
        System.out.println("Starting verifyBackNavigationFromExamSummary test");

        try {
            // Click the back button (assuming there is a back button that can be clicked)
            NavigationUtil.clickBackButton();

            int timeoutSeconds = 20;
            UtilsSet.waitForElementToBeVisible(Constants.DueExame.BY_HomeSectionTitle, timeoutSeconds);
            String homeSectionText = UtilsSet.getElementText(Constants.DueExame.BY_HomeSectionTitle);
            System.out.println("View Exams section is visible with text: " + homeSectionText);

            Assert.assertFalse(homeSectionText.isEmpty(), "dueExameSectionText should not be empty after navigating back");
            Assert.assertEquals(homeSectionText, "Welcome! Demo Student", "Mismatch text when navigating back to View Exams page");
            System.out.println("verifyBackNavigationFromExamSummary test completed successfully");
        } catch (Exception e) {
            System.err.println("Navigation back to the View Exams page failed or did not behave as expected.");
            Assert.fail("Navigation back to the View Exams page failed or did not behave as expected.", e);
        }
    }



}