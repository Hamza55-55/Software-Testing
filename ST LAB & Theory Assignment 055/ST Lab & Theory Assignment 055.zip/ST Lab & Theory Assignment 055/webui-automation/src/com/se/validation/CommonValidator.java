package com.se.validation;

public class CommonValidator {
}
